public interface Enclosures{
    public static final int FISH_PER_ENCLOSURE = 12;
    public static final int TIGERS_PER_ENCLOSURE = 2;
    public static final int DEFAULT_PER_ENCLOSURE = 1;
}