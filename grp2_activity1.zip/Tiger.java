public class Tiger extends Animal{
    protected String habitat;

    public Tiger(String type, String habitat){
        super (type, TIGERS_PER_ENCLOSURE);
        this.habitat = habitat;
    }
    @Override
    public String toString(){
        return "Tiger: " + super.toString() + ", roams in " + this.habitat;
    }
}