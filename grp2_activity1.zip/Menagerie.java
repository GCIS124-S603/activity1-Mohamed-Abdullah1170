import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class Menagerie{
    public static final String outputFilename = "Menagerie.txt";
    public static void main(String[] args) {
        Object[] an_array = new Object[5];
        Tiger tiger1 = new Tiger("Javan tiger", "Tiger acreage #6");
        Fish fish1 = new Fish("False network catfish", "Fresh water");
        Tiger tiger2 = new Tiger("Bengal tiger", "Ritchie area of RIT");
        Fish fish2 = new Fish("Shark", "Salt water");
        Tiger tiger3 = new Tiger("Siberian Tiger", "Tiger acreage #4");

        an_array[0] = tiger1;
        an_array[1] = fish1;
        an_array[2] = tiger2;
        an_array[3] = fish2;
        an_array[4] = tiger3;

        try{
            File myFile = new File(outputFilename);
            if (myFile.exists() == true){
                System.out.println("Adding to the current file " + outputFilename);
            }
            else{
                System.out.println("Creating a new file " + outputFilename);
            }           
            FileWriter fw = new FileWriter(myFile);
            PrintWriter pw = new PrintWriter(fw);
            int a = 0;
            int b = 0;
            for (int i = 0; i<an_array.length; i++){
                pw.println(an_array[i]);
                if (an_array[i] instanceof Tiger){
                    a ++;
                }
                else{
                    b ++;
                }
            }
            pw.print("Counts: "+"\n  "+b+" Fish"+"\n  "+a+" Tigers");
            pw.flush();
        } catch (IOException e){
            System.out.println("There is an error");
        }

        System.out.println("\nReport on animals...");
        int j = 0;
        int k = 0;
        for (int i=0; i<an_array.length;i++){
            System.out.println(an_array[i]);
            if (an_array[i] instanceof Tiger){
                j ++;
            }
            else{
                k ++;
            }
        }
        System.out.println("Counts: "+"\n  "+k+" Fish"+"\n  "+j+" Tigers");

    } 
}           
        

        

    
