public class Fish extends Animal{
    protected String waterType;

    public Fish(String type, String waterType){
        super(type, FISH_PER_ENCLOSURE);
        this.waterType = waterType;
    }
    @Override
    public String toString(){
        return "Fish: " + super.toString() + ", swims in " + this.waterType;
    }
}