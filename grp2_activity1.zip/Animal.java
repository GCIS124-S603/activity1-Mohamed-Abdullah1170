public class Animal implements Enclosures{
    protected String type;
    protected int occupancy;

    public Animal(String type, int occupancy){
        this.type = type;
        this.occupancy = occupancy;
    }
    public Animal(){
        this ("Undefined", DEFAULT_PER_ENCLOSURE);
    }
    @Override
    public String toString(){
        return "Numer of "+ this.type + "'s " + "per enclosure is " + this.occupancy;
    }
    
}